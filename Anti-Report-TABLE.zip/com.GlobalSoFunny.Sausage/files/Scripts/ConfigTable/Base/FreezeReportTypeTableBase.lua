local List0 = {
	[1] = {1,"CheatingFlow","CheatingFlow",101,"CheatingFlow（坐挂车）","坐挂车",80,3,604800,1,1},
	[167772160] = {167772160,"PlatformError","PlatformError",102,"PlatformError (平台验证错误)","平台验证错误",100,10,259200,0,0},
	[167772161] = {167772161,"BulletUI","BulletUI",1,"BulletUI（UI上的射击子弹坐标偏移）","UI上的射击子弹坐标偏移",100,2,259200,0,1},
	[167772162] = {167772162,"BulletSpeed","BulletSpeed",1,"BulletSpeed（子弹速度异常）","子弹速度异常",100,2,259200,0,1},
	[167772163] = {167772163,"StartBullet","StartBullet",105,"StartBullet（子弹起点异常）","子弹起点异常",70,10,259200,0,0},
	[335544320] = {335544320,"SOValue","SOValue",1,"SOValue（So文件数据验证、移速等等）","客户端与服务端数据比对",100,2,259200,0,1},
	[335544321] = {335544321,"FlyJumpSpeed","FlyJumpSpeed",2,"FlyJumpSpeed（超速飞行）","区间测速",100,3,259200,0,1},
	[335544322] = {335544322,"UseItemNoTime","UseItemNoTime",2,"UseItemNoTime（0秒嗑药）","服務器计算使用时间",70,3,259200,0,1},
	[335544323] = {335544323,"BombRange","BombRange",1,"BombRange（手雷范围）","服务端检测受伤害角色距离",70,2,259200,0,1},
	[335544324] = {335544324,"ChangeHurtPower","ChangeHurtPower",104,"ChangeHurtPower（修改伤害）","伤害无效",100,10,259200,0,0},
	[335544325] = {335544325,"ChangeFireBulletNum","ChangeFireBulletNum",1,"ChangeFireBulletNum（改变一次射出的子弹数量）","服务端检验数",100,2,259200,0,1},
	[335544326] = {335544326,"JumpNoLimit","JumpNoLimit",2,"JumpNoLimit（无限跳跃）","角色高度超过某个范围",90,3,259200,0,1},
	[335544327] = {335544327,"CharacterSize","CharacterSize",1,"CharacterSize（飞天遁地）","服务端检验数据",100,2,259200,0,1},
	[335544328] = {335544328,"HideWall","HideWall",1,"HideWall（子弹穿墙）","子弹穿过障碍物击中3个不同的敌人",100,2,259200,0,1},
	[335544329] = {335544329,"WeaponError","WeaponError",1,"WeaponError（射击时间，无扩散，无后座）","客户端与服务端数据比对",70,2,259200,0,1},
	[335544330] = {335544330,"CameraRatio","CameraRatio",2,"CameraRatio（倍镜倍率）","服务端检验数据",70,3,259200,0,1},
	[335544331] = {335544331,"MTP","MTP",2,"MTP","MTPSDK发起",100,3,259200,0,1},
	[335544332] = {335544332,"MTPSimulator","MTPSimulator",103,"MTPSimulator(MTP模拟器)","MTP模拟器",100,10,259200,0,0},
	[335544333] = {335544333,"CheckMoveX","CheckMoveX",2,"CheckMoveX","服务器移动区间测速（X Z）",100,3,259200,0,1},
	[335544334] = {335544334,"CheckMoveY","CheckMoveY",2,"CheckMoveY","服务器移动区间测速（Y）",100,3,259200,0,1},
	[335544335] = {335544335,"RoleMoveToY","RoleMoveToY",2,"RoleMoveToY","检测玩家Y轴坐标是否异常",100,3,259200,0,1},
	[335544336] = {335544336,"HookFlyDistance","HookFlyDistance",2,"HookFlyDistance","拉勾勾飞行距离异常",100,3,259200,0,1},
	[335544337] = {335544337,"BulletError","BulletError",1,"BulletError","子弹击中判定模拟（用以防护子弹追踪）",100,2,259200,0,1},
	[335544339] = {335544339,"DownHpHitDistance","DownHpHitDistance",1,"DownHpHitDistance","防护子弹追踪",100,2,259200,0,1},
	[335544340] = {335544340,"MTPTimeOver","MTPTimeOver",2,"MTPTimeOver","MTP无响应状态",90,3,259200,0,1},
	[335544341] = {335544341,"ItemNumError","ItemNumError",1,"ItemNumError","无限物资",100,2,259200,0,1},
	[335544342] = {335544342,"AttackTimeLimit","AttackTimeLimit",2,"AttackTimeLimit","圣剑攻击无间隔",100,3,259200,0,1},
	[335544343] = {335544343,"BombHurt","BombHurt",2,"BombHurt","爆炸物伤害检测",100,3,259200,0,1},
	[335544344] = {335544344,"FirePoint","FirePoint",2,"FirePoint","子弹起点坐标偏差",100,3,259200,0,1},
	[335544345] = {335544345,"PowerError","PowerError",1,"PowerError","对载具造成的伤害异常",100,2,259200,0,1},
	[335544346] = {335544346,"GlideFlyError","GlideFlyError",1,"GlideFlyError","平地飞高高",100,2,259200,0,1},
	[335544347] = {335544347,"ShiftDeviceDistance","ShiftDeviceDistance",1,"ShiftDeviceDistance","虫洞手雷距离异常",100,2,259200,0,1},
	[335544348] = {335544348,"PointError","PointError",2,"PointError","坐标异常（胶囊锁毒）",100,3,259200,0,1},
	[335544349] = {335544349,"HoldOnXCCDistance","HoldOnXCCDistance",2,"HoldOnXCCDistance","抱起小肠肠距离异常",100,3,259200,0,1},
	[335544350] = {335544350,"UprearUseTime","UprearUseTime",2,"UprearUseTime","扶起小肠肠时间异常",100,3,259200,0,1},
	[335544351] = {335544351,"AbnormalRide","AbnormalRide",116,"AbnormalRide","恶意组队",90,3,259200,0,1},
	[335544352] = {335544352,"AbnormalHeadShot","AbnormalHeadShot",117,"AbnormalHeadShot","爆头率异常",90,1,259200,0,1},
	[436207616] = {436207616,"RoleSize","RoleSize",1,"RoleSize","模型大小检测",100,2,259200,0,1},
	[436207617] = {436207617,"ExteriorDevice","ExteriorDevice",111,"ExteriorDevice","使用外设",100,100,259200,0,1},
	[603979776] = {603979776,"NewlyAccountDataAbnormal","NewlyAccountDataAbnormal",112,"NewlyAccountDataAbnormal（新号数据异常）","新号数据异常",80,1,259200,0,1},
	[838860800] = {838860800,"AcountDataAbnormal","AcountDataAbnormal",110,"AcountDataAbnormal","账号击杀数异常",100,1,259200,0,1},
	[838860801] = {838860801,"AccountDataCritAbnormal","AccountDataCritAbnormal",113,"AccountDataCritAbnormal（击杀数严重异常）","击杀数严重异常",100,1,259200,2,1},
	[838860802] = {838860802,"IdentityCheating","IdentityCheating",114,"IdentityCheating","身份证处罚",100,1,259200,3,1},
	[872415232] = {872415232,"DeviceIdCheating","DeviceIdCheating",115,"DeviceIdCheating","设备处罚",100,1,259200,3,1},
}

local Keys = {1,167772160,167772161,167772162,167772163,335544320,335544321,335544322,335544323,335544324,335544325,335544326,335544327,335544328,335544329,335544330,335544331,335544332,335544333,335544334,335544335,335544336,335544337,335544339,335544340,335544341,335544342,335544343,335544344,335544345,335544346,335544347,335544348,335544349,335544350,335544351,335544352,436207616,436207617,603979776,838860800,838860801,838860802,872415232,}



local FreezeReportTypeTableBase = {

    -- 记录数
	COUNT = 45,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,



    -- 字段索引
	id = 1,
	sign = 0,
	report_type = 0,
	punish_type = 0,
	name = 0,
	description = 0,
	precision_rate = 0,
	threshold = 0,
	record_time = 0,
	freeze_report_type_reason_id = false,
	is_use = 0,

    -- 标识常量
	["CheatingFlow"] = "CheatingFlow",
	["PlatformError"] = "PlatformError",
	["BulletUI"] = "BulletUI",
	["BulletSpeed"] = "BulletSpeed",
	["StartBullet"] = "StartBullet",
	["SOValue"] = "SOValue",
	["FlyJumpSpeed"] = "FlyJumpSpeed",
	["UseItemNoTime"] = "UseItemNoTime",
	["BombRange"] = "BombRange",
	["ChangeHurtPower"] = "ChangeHurtPower",
	["ChangeFireBulletNum"] = "ChangeFireBulletNum",
	["JumpNoLimit"] = "JumpNoLimit",
	["CharacterSize"] = "CharacterSize",
	["HideWall"] = "HideWall",
	["WeaponError"] = "WeaponError",
	["CameraRatio"] = "CameraRatio",
	["MTP"] = "MTP",
	["MTPSimulator"] = "MTPSimulator",
	["CheckMoveX"] = "CheckMoveX",
	["CheckMoveY"] = "CheckMoveY",
	["RoleMoveToY"] = "RoleMoveToY",
	["HookFlyDistance"] = "HookFlyDistance",
	["BulletError"] = "BulletError",
	["DownHpHitDistance"] = "DownHpHitDistance",
	["MTPTimeOver"] = "MTPTimeOver",
	["ItemNumError"] = "ItemNumError",
	["AttackTimeLimit"] = "AttackTimeLimit",
	["BombHurt"] = "BombHurt",
	["FirePoint"] = "FirePoint",
	["PowerError"] = "PowerError",
	["GlideFlyError"] = "GlideFlyError",
	["ShiftDeviceDistance"] = "ShiftDeviceDistance",
	["PointError"] = "PointError",
	["HoldOnXCCDistance"] = "HoldOnXCCDistance",
	["UprearUseTime"] = "UprearUseTime",
	["AbnormalRide"] = "AbnormalRide",
	["AbnormalHeadShot"] = "AbnormalHeadShot",
	["RoleSize"] = "RoleSize",
	["ExteriorDevice"] = "ExteriorDevice",
	["NewlyAccountDataAbnormal"] = "NewlyAccountDataAbnormal",
	["AcountDataAbnormal"] = "AcountDataAbnormal",
	["AccountDataCritAbnormal"] = "AccountDataCritAbnormal",
	["IdentityCheating"] = "IdentityCheating",
	["DeviceIdCheating"] = "DeviceIdCheating",
}



return FreezeReportTypeTableBase